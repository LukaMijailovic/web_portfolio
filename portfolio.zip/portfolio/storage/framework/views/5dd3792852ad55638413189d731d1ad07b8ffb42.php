<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <h1>Contact succes!!</h1>
    <p>Bedankt voor het versturen, <?php echo e($voornaam); ?></p>
</body>
</html><?php /**PATH C:\laragon\www\portfolio\resources\views/contact_success.blade.php ENDPATH**/ ?>