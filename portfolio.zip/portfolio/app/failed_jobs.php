<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class failed_jobs extends Model
{
    //
}
