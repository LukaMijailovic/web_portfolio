<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
</head>
<body>
    <header>
        <h1>Admin Panel</h1>
    </header>

        <a src="/addwork">Add Work</a>
        <a src="/updatework">Update Work</a>
        <a src="/deletework">Delete Work</a>

    <style>


    body{
        background-color: #FFFFF0;
    }

    h1{
        font-family: Monospace;
        font-size: 300%;
        margin-left: 36%;
        width: 30%;
        text-align: center;
        color:white;
    }

    header{
        border: 2px solid black;
        width:50%;
        margin-left: 24%;
        margin-top: 2%;
        font-family: Monospace;
        background-color: black;
    }

    a{
        float:left;
        margin-top: 10%;
        margin-left: 15.5%;
        font-family: Monospace;
        font-size: 300%;
        border: 1px solid black;
        padding:1%;
    }

</style>
</body>
</html><?php /**PATH C:\laragon\www\portfolio\resources\views/dashboard.blade.php ENDPATH**/ ?>