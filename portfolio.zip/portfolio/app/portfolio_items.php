<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class portfolio_items extends Model
{
    //
}
